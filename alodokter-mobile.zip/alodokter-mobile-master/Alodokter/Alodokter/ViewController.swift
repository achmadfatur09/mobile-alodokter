//
//  ViewController.swift
//  Alodokter
//
//  Created by Ferdinand on 19/08/19.
//  Copyright © 2019 Ferdinand. All rights reserved.
//

import UIKit
import MaterialComponents

class ViewController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var emailTextField: MDCTextField!
    var emailController = MDCTextInputControllerUnderline()
    @IBOutlet weak var passwordTextField: MDCTextField!
    var passwordController = MDCTextInputControllerUnderline()
    
    var allTextFieldControllers = [MDCTextInputControllerUnderline]()
    
    let service = "Alodokter"

    override func viewDidLoad() {
        super.viewDidLoad()
            
        self.navigationItem.titleView = UIImageView.init(image: UIImage(named:"ic_mall_icon"))
        initView()
        registerKeyboardNotifications()
        addGestureRecognizer()
        
    }
        
    func initView() {
            
        initTextField()
            
        loginButton.layer.cornerRadius = 6.0
        loginButton.layer.masksToBounds = true
        loginButton.addTarget(self, action: #selector(pushToChooseMall), for: .touchUpInside)
            
    }
        
    func initTextField() {
        
        emailTextField.delegate = self                  //set delegate to textfile
        emailTextField.autocapitalizationType = .none
        emailController = MDCTextInputControllerUnderline(textInput: emailTextField)
        emailController.placeholderText = "Enter your email address"
        emailController.isFloatingEnabled = false
        emailController.activeColor = UIColor.init(rgb: 0x2489bf)
        
        allTextFieldControllers.append(emailController)
        
        passwordTextField.delegate = self                  //set delegate to textfile
        passwordTextField.autocapitalizationType = .none
        passwordTextField.isSecureTextEntry = true
        passwordController = MDCTextInputControllerUnderline(textInput: passwordTextField)
        passwordController.placeholderText = "Enter your password"
        passwordController.isFloatingEnabled = false
        passwordController.activeColor = UIColor.init(rgb: 0x2489bf)
        allTextFieldControllers.append(passwordController)
        
        var tag = 0
        for controller in allTextFieldControllers {
            guard let textField = controller.textInput as? MDCTextField else { continue }
            textField.tag = tag
            tag += 1
        }
            
    }
    
    func addGestureRecognizer() {
        let tapRecognizer = UITapGestureRecognizer(target: self,
                                                    action: #selector(tapDidTouch(sender: )))
        self.scrollView.addGestureRecognizer(tapRecognizer)
    }
        
    // MARK: - Actions
        
    @objc func tapDidTouch(sender: Any) {
        self.view.endEditing(true)
    }
        
    @objc func pushToChooseMall(_ sender: UIButton) {
        
        self.view.endEditing(true)
        do {
                
            let email = try self.emailTextField.validatedText(validationType: .requiredField(field: "Email"))
            let password = try self.passwordTextField.validatedText(validationType: .requiredField(field: "Password"))
            KeychainService.savePassword(service: service, account: email, data: password)
            let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate
            appDelegate?.pushToHomeViewController()
        } catch(let error) {
            let alertController = UIAlertController(title: nil, message: (error as! ValidationError).message, preferredStyle: UIAlertController.Style.alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(alertAction)
            present(alertController, animated: true, completion: nil)
        }
            
    }
}
    
// MARK: - Keyboard Handling
    
extension ViewController {
    func registerKeyboardNotifications() {
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(
            self,
            selector: #selector(keyboardWillShow(notif:)),
            name: UIResponder.keyboardWillShowNotification,
            object: nil)
        notificationCenter.addObserver(
            self,
            selector: #selector(keyboardWillHide(notif:)),
            name: UIResponder.keyboardWillHideNotification,
            object: nil)
        notificationCenter.addObserver(
            self,
            selector: #selector(keyboardWillShow(notif:)),
            name: UIResponder.keyboardWillChangeFrameNotification,
            object: nil)
    }
    
    @objc func keyboardWillShow(notif: Notification) {
        guard let frame = notif.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else {
            return
        }
        
        scrollView.contentInset = UIEdgeInsets(top: 0.0, left: 0.0, bottom: frame.height, right: 0.0)
    }
        
    @objc func keyboardWillHide(notif: Notification) {
        scrollView.contentInset = UIEdgeInsets()
    }
}

extension ViewController: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        emailController.setErrorText(nil, errorAccessibilityValue: nil)
        passwordController.setErrorText(nil, errorAccessibilityValue: nil)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == emailTextField {
            
            do {
                _ = try textField.validatedText(validationType: ValidatorType.email)
                
                emailController.setErrorText(nil, errorAccessibilityValue: nil)
            } catch(let error) {
                emailController.setErrorText((error as! ValidationError).message,
                                             errorAccessibilityValue: nil)
            }
            
        } else if textField == passwordTextField {
            
            do {
                _ = try textField.validatedText(validationType: ValidatorType.password)
                
                passwordController.setErrorText(nil, errorAccessibilityValue: nil)
            } catch(let error) {
                passwordController.setErrorText((error as! ValidationError).message,
                                                errorAccessibilityValue: nil)
            }
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let index = textField.tag
        if index + 1 < allTextFieldControllers.count,
            let nextField = allTextFieldControllers[index + 1].textInput {
            nextField.becomeFirstResponder()
        } else {
            textField.resignFirstResponder()
        }
        
        return false
    }
}

extension UITextField {
    func validatedText(validationType: ValidatorType) throws -> String {
        let validator = VaildatorFactory.validatorFor(type: validationType)
        return try validator.validated(self.text!)
    }
}
